# Spec 01: Profiling del Dataset Vendite

**Autore:** Nicola Iantomasi
**Data:** 2026-03-31  
**Stato:** Da implementare

## Obiettivo
Ottenere una fotografia completa del dataset vendite prima di qualsiasi
analisi. Capire cosa abbiamo, cosa manca, e cosa sembra strano.

## Dati di input
- `data/vendite_2025.csv` — transazioni di vendita gennaio 2025
- `data/clienti.csv` — anagrafica clienti

## Domande a cui rispondere
1. Quante transazioni abbiamo? Quanti clienti unici? Quanti negozi?
2. Qual è il range temporale coperto?
3. Ci sono valori mancanti? In quali colonne? Quanti?
4. Ci sono righe duplicate?
5. Ci sono valori che non hanno senso (negativi, fuori range)?
6. Come sono distribuite le vendite per negozio e categoria?
7. I dati in clienti.csv coprono tutti i cliente_id delle vendite?

## Output attesi
- Stampa a terminale con riepilogo chiave
- File `output/profiling_report.md` con il dettaglio completo
- Nessun grafico in questa fase — solo numeri e tabelle

## Criteri di accettazione
- [ ] Tutte e 7 le domande hanno una risposta nel report
- [ ] I valori mancanti sono quantificati per colonna (conteggio + percentuale)
- [ ] I duplicati sono identificati con i numeri di riga
- [ ] Le anomalie sono listate con spiegazione
- [ ] Il report è leggibile da un non-tecnico
