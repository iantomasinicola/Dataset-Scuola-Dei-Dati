# Spec 03: Report Analisi Vendite Gennaio 2025

**Autore:** Nicola Iantomasi
**Data:** 2026-03-31  
**Stato:** Da implementare  
**Dipende da:** Spec 02 (pulizia completata)

## Obiettivo
Produrre un report di analisi vendite per il management, con insight
azionabili e visualizzazioni chiare. Il report deve rispondere alla
domanda: "come è andato gennaio 2025?"

## Pubblico
Direttore commerciale e responsabili di negozio. Non tecnici.
Il report deve essere comprensibile senza conoscenze di analisi dati.

## Dati di input
- `data/vendite_2025_clean.csv` — dataset pulito
- `data/clienti.csv` — anagrafica clienti
- `data/resi_2025.csv` — resi del periodo

## Analisi richieste

### A. Performance per negozio
- Fatturato totale per negozio
- Numero transazioni per negozio
- Scontrino medio per negozio
- Classifica negozi dal migliore al peggiore
- **Grafico:** barre orizzontali, fatturato per negozio

### B. Performance per categoria
- Fatturato totale per categoria prodotto
- Categoria con margine (scontrino medio) più alto
- **Grafico:** barre, fatturato per categoria

### C. Trend temporale
- Fatturato giornaliero nel mese
- Ci sono pattern settimanali? (weekend vs feriali)
- Giorni di picco e giorni deboli
- **Grafico:** linea, fatturato giornaliero con media mobile 7gg

### D. Analisi clienti
- Quanti clienti unici hanno acquistato
- Top 5 clienti per spesa totale (join con anagrafica)
- Distribuzione clienti per segmento (Premium vs Standard)
- Clienti registrati che NON hanno acquistato a gennaio
- **Grafico:** torta, distribuzione per segmento

### E. Metodi di pagamento
- Distribuzione per metodo di pagamento (conteggio e valore)
- Scontrino medio per metodo di pagamento
- **Grafico:** barre raggruppate

### F. Resi
- Quanti resi ci sono stati
- Valore totale dei resi
- Impatto percentuale sui ricavi lordi

## Specifiche grafici
- Libreria: matplotlib + seaborn
- Stile: `sns.set_theme(style="whitegrid")`
- Palette: `["#0D9488", "#14B8A6", "#5EEAD4", "#F59E0B", "#64748B"]`
- Dimensione: `figsize=(10, 6)` per tutti
- Ogni grafico ha: titolo, etichette assi, legenda se necessaria
- Salvare come PNG a 150 DPI in `output/grafici/`
- Nomi file: `01_fatturato_negozio.png`, `02_fatturato_categoria.png`, ecc.

## Formato report
- File: `output/report_vendite_gennaio_2025.md`
- Struttura:
  1. Executive Summary (5 bullet point max, numeri chiave)
  2. Performance Negozi
  3. Performance Categorie
  4. Trend Temporale
  5. Analisi Clienti
  6. Metodi di Pagamento
  7. Resi e Anomalie
  8. Raccomandazioni (3-5 azioni concrete suggerite)
- Numeri in formato europeo: 1.234,56 €
- I grafici referenziati nel markdown con path relativo

## Script
- `scripts/report.py` — genera tutto il report e i grafici
- Deve essere riutilizzabile: cambiando i file di input deve funzionare
  per febbraio, marzo, ecc.

## Criteri di accettazione
- [ ] Tutte e 6 le analisi (A-F) sono presenti nel report
- [ ] Almeno 5 grafici salvati in output/grafici/
- [ ] L'executive summary è comprensibile da un non-tecnico
- [ ] Le raccomandazioni sono concrete e azionabili
- [ ] Lo script è riutilizzabile con parametri diversi
- [ ] Il report non contiene gergo tecnico (no "DataFrame", "groupby", ecc.)
- [ ] Tutti i numeri monetari sono formattati in euro con separatore europeo
