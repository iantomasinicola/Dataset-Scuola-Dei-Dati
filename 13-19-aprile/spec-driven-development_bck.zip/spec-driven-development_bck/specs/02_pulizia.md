# Spec 02: Pulizia Dati Vendite

**Autore:** Nicola Iantomasi
**Data:** 2026-03-31  
**Stato:** Da implementare  
**Dipende da:** Spec 01 (profiling completato)

## Obiettivo
Produrre una versione pulita del dataset vendite, pronta per l'analisi.
Ogni decisione di pulizia deve essere giustificata e loggata.

## Dati di input
- `data/vendite_2025.csv` — dataset grezzo
- `output/profiling_report.md` — risultati del profiling (per sapere cosa pulire)

## Problemi noti (da Spec 01)
Questi sono i problemi che ci aspettiamo di trovare. La pipeline deve
gestirli tutti:

1. **Duplicati** — almeno una riga duplicata esatta
2. **Valori mancanti in cliente_id** — acquisti anonimi (leciti)
3. **Valore mancante in totale** — da ricalcolare come quantità × prezzo
4. **Quantità negativa** — probabilmente un reso, da gestire separatamente

## Regole di pulizia

### Duplicati
- Rimuovere le righe identiche, tenere la prima occorrenza
- Loggare: quali righe, quante rimosse

### Valori mancanti
- `cliente_id` nullo: LASCIARE (gli acquisti anonimi sono validi)
- `totale` nullo: RICALCOLARE come `quantita × prezzo_unitario`
- Altri campi nulli: segnalare ma non rimuovere

### Resi (quantità negativa)
- NON rimuovere — spostarli in un file separato `data/resi_2025.csv`
- Nel dataset principale tenere solo le vendite (quantità > 0)

### Normalizzazione
- Trim degli spazi nei campi testo
- Uniformare maiuscole/minuscole nelle categorie (se inconsistenti)
- Verificare che le date siano tutte nel formato corretto

## Output attesi
- `data/vendite_2025_clean.csv` — dataset pulito
- `data/resi_2025.csv` — resi estratti
- `output/pulizia_log.md` — log completo di tutte le operazioni
- `scripts/pulizia.py` — script riutilizzabile

## Criteri di accettazione
- [ ] Il file originale `data/vendite_2025.csv` NON è stato modificato
- [ ] Il dataset pulito non ha duplicati
- [ ] Il campo `totale` non ha valori nulli
- [ ] I resi sono in un file separato
- [ ] Il log documenta ogni operazione con conteggio righe prima/dopo
- [ ] Lo script è riutilizzabile su nuovi dati mensili
- [ ] Tabella riepilogo nel log: righe originali → righe finali, con breakdown
