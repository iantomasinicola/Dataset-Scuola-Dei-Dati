# Progetto Demo: Spec-Driven Development per Data Analyst

## Descrizione
Analisi vendite retail di una catena con 4 negozi italiani — gennaio 2025.
Questo progetto segue il metodo **Spec-Driven Development**: prima si scrive
la specifica, poi si progetta la soluzione, infine si implementa.

## Stack tecnico
- Python 3.11+
- pandas, matplotlib, seaborn per analisi e visualizzazione
- scikit-learn (se necessario per modelli predittivi)

## Python e virtualenv
Usa SEMPRE il Python del virtualenv tramite path diretto:
- `.venv/bin/python` su Linux, Mac e Git Bash (anche su Windows via Claude Code)
- `.venv/Scripts/python` su Windows CMD

NON usare mai `python` o `python3` senza path — potrebbe puntare al Python
di sistema dove le librerie non sono installate.

Esempi corretti:
- `.venv/Scripts/python scripts/profiling.py`
- `.venv/Scripts/python -c "import pandas; print(pandas.__version__)"`
- `.venv/Scripts/pip list`

Questo vale per OGNI comando Python, senza eccezioni. Ogni comando che
esegui gira in una shell separata, quindi `source .venv/bin/activate`
non ha effetto sui comandi successivi.

## Struttura progetto
```
├── CLAUDE.md              ← Questo file (contesto progetto)
├── specs/                 ← Specifiche di analisi (scritte dall'analyst)
│   ├── 01_profiling.md
│   ├── 02_pulizia.md
│   └── 03_report_vendite.md
├── design/                ← Design documents (generati con Claude)
├── data/                  ← Dati grezzi — NON MODIFICARE MAI
├── output/                ← Report e grafici generati
│   └── grafici/
├── scripts/               ← Script Python riutilizzabili
└── .claude/
    ├── settings.json      ← Permessi e configurazione
    └── skills/            ← Skill personalizzate
```

## Regole FONDAMENTALI
- NON modificare MAI i file originali nella cartella data/
- Salvare i dati puliti come data/nome_file_clean.csv
- NON installare librerie senza approvazione esplicita
- I grafici vanno salvati come PNG a 150 DPI in output/grafici/
- Commenta il codice in italiano
- Formato numeri europeo nei report: 1.234,56 €
- Date nel formato GG/MM/AAAA

## Workflow Spec-Driven
Quando l'utente chiede di lavorare su un'analisi:
1. Cerca PRIMA la spec corrispondente in specs/
2. Se esiste un design document in design/, segui quello
3. Se non esistono, chiedi all'utente se vuole crearli
4. MAI implementare senza una spec approvata

## Comandi utili
- `.venv/Scripts/python scripts/profiling.py` — profiling del dataset
- `.venv/Scripts/python scripts/pulizia.py` — pipeline di pulizia
- `.venv/Scripts/python scripts/report.py` — genera il report finale
- `ls specs/` — vedi le specifiche disponibili
