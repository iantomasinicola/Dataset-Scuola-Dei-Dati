---
name: check-spec
description: Verifica i criteri di accettazione di una specifica implementata. Usa quando l'utente chiede di verificare, controllare, validare il lavoro fatto, o dice "controlla la spec", "è tutto ok?", "verifica i criteri".
---

# Skill: Verifica Criteri di Accettazione

Controlla sistematicamente se tutti i criteri di accettazione di una spec
sono soddisfatti dopo l'implementazione.

## Processo

1. Identifica la spec da verificare (chiedi se non specificato)
2. Leggi la spec e estrai tutti i criteri di accettazione
3. Per ogni criterio:
   - Verifica concretamente (controlla che i file esistano, leggi i contenuti,
     conta righe, verifica formati)
   - Segna ✅ se soddisfatto, ❌ se non soddisfatto
   - Per ogni ❌ spiega cosa manca
4. Stampa il riepilogo:

```
VERIFICA SPEC: [nome spec]
━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ [criterio soddisfatto]
✅ [criterio soddisfatto]
❌ [criterio non soddisfatto] → [cosa manca]

Risultato: X/Y criteri soddisfatti
```

5. Se ci sono criteri non soddisfatti, proponi le azioni correttive

## Regole
- Non barare: verifica davvero, non fidarti del log
- Se un file deve esistere, controlla con ls
- Se un report deve contenere certe sezioni, leggilo e verifica
- Se i grafici devono esistere, controlla che siano in output/grafici/
