---
name: new-spec
description: Crea una nuova specifica di analisi. Usa quando l'utente vuole scrivere una spec, definire un'analisi nuova, pianificare un lavoro sui dati, o dice "voglio analizzare X", "crea una spec per Y".
---

# Skill: Creazione Nuova Specifica

Aiuta l'utente a scrivere una spec chiara e completa per un'analisi dati.

## Processo

### 1. Raccogli i requisiti
Fai queste domande all'utente (una alla volta, non tutte insieme):

- **Obiettivo**: "Cosa vuoi scoprire o ottenere da questa analisi?"
- **Dati**: "Quali file di dati useremo?" (elenca quelli disponibili in data/)
- **Pubblico**: "Chi leggerà il risultato? Tecnici o non tecnici?"
- **Output**: "Cosa vuoi come deliverable? Report, grafici, script, dashboard?"
- **Vincoli**: "Ci sono vincoli particolari? Formato, scadenze, limitazioni?"

### 2. Genera la spec
Crea un file in `specs/` con il prossimo numero progressivo e questa struttura:

```markdown
# Spec [NN]: [Titolo descrittivo]

**Autore:** [chiedi il nome]
**Data:** [data odierna]
**Stato:** Da implementare
**Dipende da:** [eventuali spec precedenti]

## Obiettivo
[1-3 frasi che descrivono il perché di questa analisi]

## Dati di input
[lista dei file con breve descrizione]

## Analisi richieste
[elenco numerato delle analisi specifiche da fare]

## Output attesi
[lista di file, report, grafici da produrre]

## Criteri di accettazione
[checklist con checkbox markdown - [ ] per ogni criterio]
```

### 3. Revisione
- Mostra la spec all'utente
- Chiedi se vuole aggiungere, rimuovere, o modificare qualcosa
- Itera fino a che l'utente approva
- Salva la versione finale

## Regole
- La spec deve essere comprensibile da un non-tecnico
- I criteri di accettazione devono essere verificabili (sì/no)
- Non usare gergo tecnico nella descrizione dell'obiettivo
- Suggerisci analisi aggiuntive che l'utente potrebbe non aver pensato
