---
name: implement-spec
description: Implementa una specifica di analisi seguendo il workflow Spec-Driven Development. Usa quando l'utente chiede di implementare, eseguire, o lavorare su una spec, oppure dice "implementa la spec", "esegui la spec", "lavora sulla spec X".
---

# Skill: Implementazione Spec-Driven

Quando viene invocata, segui questo workflow in 3 fasi rigorose.

## Fase 1 — Lettura e comprensione della spec

1. Identifica quale spec implementare:
   - Se l'utente ha specificato un nome/numero, cerca in `specs/`
   - Se non ha specificato, elenca le spec disponibili e chiedi quale
2. Leggi la spec completa
3. Verifica le dipendenze: se la spec dipende da un'altra, controlla che
   l'output di quella sia già presente (es. se serve il dataset pulito,
   verifica che `data/vendite_2025_clean.csv` esista)
4. Se mancano dipendenze, avvisa e proponi di implementare prima quelle

## Fase 2 — Design (chiedi approvazione)

1. Produci un documento di design in `design/` con:
   - Riepilogo della spec (1-2 righe)
   - Passi di implementazione numerati
   - Librerie necessarie (e verifica che siano disponibili nel virtualenv)
   - File che verranno creati/modificati
   - Rischi o assunzioni
2. Mostra il design all'utente
3. **FERMATI e chiedi approvazione esplicita prima di procedere**
4. Se l'utente chiede modifiche, aggiorna il design e richiedi approvazione

## Fase 3 — Implementazione

Solo dopo approvazione:
1. Usa SEMPRE `.venv/Scripts/python` per eseguire Python (path diretto al virtualenv,
   non usare `python` senza path — ogni comando gira in una shell separata)
2. Implementa seguendo esattamente i passi del design
3. Dopo ogni passo significativo, mostra un breve log di avanzamento
4. Al termine, verifica i criteri di accettazione dalla spec uno per uno
5. Riporta quali criteri sono soddisfatti e quali no
6. Salva lo script in `scripts/` per renderlo riutilizzabile

## Regole
- MAI saltare la Fase 2 (design)
- MAI procedere senza approvazione
- MAI modificare file in `data/` (solo lettura)
- Sempre loggare le operazioni fatte
- Se qualcosa va storto, fermati e spiega — non inventare workaround
